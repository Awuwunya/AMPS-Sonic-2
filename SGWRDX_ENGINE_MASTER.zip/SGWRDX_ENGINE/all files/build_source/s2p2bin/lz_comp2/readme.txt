This is the original source code used to develop Sonic Team's Saxman compressor.

Modifications have been made to make it work with s2p2bin, and produce identical
files (the original code lacks the ability to create zero-fill matches).

You can find the unaltered source code here:
https://web.archive.org/web/19990203141013/http://oak.oakland.edu/pub/simtelnet/msdos/arcutils/lz_comp2.zip
