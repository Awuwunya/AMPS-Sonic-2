comp_z80_size 0x80A e f�r C-Programm */
#define word_728C_user 0x6D2A
#define Obj_EndingController_MapUnc_7240 0x6DBC
#define off_3A294 0x398A4
#define MapRUnc_Sonic 0x87A30
/* Ende Includefile f�r C-Programm */
